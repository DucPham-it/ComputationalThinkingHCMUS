CREATE TABLE users (
    id INT PRIMARY KEY,
    user_name NVARCHAR(255) NOT NULL,
    email NVARCHAR(255) NOT NULL,
    password_hash NVARCHAR(255) NOT NULL
);
